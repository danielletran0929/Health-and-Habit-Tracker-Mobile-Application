import { StyleSheet } from 'react-native';

export default  StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fff9',
    padding: 20,
  },
  title: {
    backgroundColor: '#b8e0b0',
    padding: 20,
    textAlign: 'center',
    fontSize: 18,
    color: '#2f6b50',
    marginBottom: 5,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#b8e0b0',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    marginTop: 10,
  },
  header: {
    fontSize: 18,
    color: '#2f6b50',
    marginBottom: 10,
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  box: {
    backgroundColor: '#a9d8a0',
    borderRadius: 10,
    overflow: 'hidden',
  },
  innerPicker: {
    height: 150,
    width: 80,
    color: '#2f6b50',
  },
  colon: {
    fontSize: 28,
    color: '#2f6b50',
    marginHorizontal: 5,
  },
  dndContainer: {
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
    marginTop: 5,
  },
  dndText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
  },
  periodContainer: {
    flexDirection: 'column',
    marginLeft: 10,
  },
  periodButton: {
    backgroundColor: '#a9d8a0',
    borderRadius: 8,
    paddingVertical: 5,
    paddingHorizontal: 15,
    marginVertical: 2,
  },
  periodActive: {
    backgroundColor: '#77b86c',
  },
  periodText: {
    fontSize: 16,
    color: '#2f6b50',
    fontWeight: '600',
  },
  liveTimeText: {
    textAlign: 'center',
    fontSize: 20,
    fontWeight: '600',
    color: '#2f6b50',
    marginTop: 10,
  },
  setButton: {
    backgroundColor: '#77b86c',
    paddingVertical: 10,
    paddingHorizontal: 40,
    borderRadius: 10,
    marginTop: 15,
  },
  setButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  subTitle: {
    fontSize: 20,
    marginVertical: 12,
    color: '#2f6b50',
  },
  alarmListContainer: {
    flex: 1,
    maxHeight: 400,
  },
  components: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  alarmText: {
    fontSize: 20,
    color: '#111',
  },
  alarmActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  deleteButton: {
    marginLeft: 10,
    padding: 6,
  },
  deleteText: {
    fontSize: 20,
    color: 'red',
  },
  empty: {
    color: '#666',
  },

  dndOn: {
  backgroundColor: '#b9e4c2',
},
dndOff: {
  backgroundColor: '#f8caca',
},

});

