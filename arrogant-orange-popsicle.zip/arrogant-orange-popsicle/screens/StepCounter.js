import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { accelerometer, setUpdateIntervalForType, SensorTypes } from 'react-native-sensors';
import { map, filter } from 'rxjs/operators';
import { stepEmitter } from './StepEvents';

const StepCounter = () => {
  const [steps, setSteps] = useState(0);
  const [records, setRecords] = useState({});
  const [prevMagnitude, setPrevMagnitude] = useState(0);
  const [currentDate, setCurrentDate] = useState(new Date().toISOString().split('T')[0]);

  // Load saved records
  useEffect(() => { loadRecords(); }, []);

  // Accelerometer subscription
  useEffect(() => {
    setUpdateIntervalForType(SensorTypes.accelerometer, 250);

    const subscription = accelerometer
      .pipe(
        map(({ x, y, z }) => Math.sqrt(x * x + y * y + z * z)),
        filter((magnitude) => {
          const threshold = 1.2;
          const isStep = magnitude - prevMagnitude > threshold;
          setPrevMagnitude(magnitude);
          return isStep;
        })
      )
      .subscribe(() => {
        const newCount = steps + 1;
        setSteps(newCount);
        saveSteps(newCount);
        stepEmitter.emit('update', newCount); // live update
      });

    return () => subscription.unsubscribe();
  }, [steps, prevMagnitude]);

  const saveSteps = async (count) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const updated = { ...records, [today]: count };
      setRecords(updated);
      await AsyncStorage.setItem('@step_records', JSON.stringify(updated));
    } catch (e) { console.log('Error saving steps:', e); }
  };

  const loadRecords = async () => {
    try {
      const saved = await AsyncStorage.getItem('@step_records');
      if (saved) {
        const parsed = JSON.parse(saved);
        setRecords(parsed);

        const today = new Date().toISOString().split('T')[0];
        if (parsed[today]) setSteps(parsed[today]);
      }
    } catch (e) { console.log('Error loading records:', e); }
  };

  // Day change detection
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().toISOString().split('T')[0];
      if (now !== currentDate) handleNewDay(now);
    }, 60000);
    return () => clearInterval(interval);
  }, [currentDate, records, steps]);

  const handleNewDay = async (newDate) => {
    try {
      const updated = { ...records, [currentDate]: steps };
      await AsyncStorage.setItem('@step_records', JSON.stringify(updated));
      setRecords(updated);
      setSteps(0);
      setCurrentDate(newDate);
      stepEmitter.emit('update', 0); // reset live update
    } catch (e) { console.log('Error handling new day:', e); }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>🏃 Step Counter</Text>
      <View style={styles.card}>
        <Text style={styles.counter}>{steps}</Text>
        <Text style={styles.label}>Steps Today</Text>
        <Text style={styles.date}>{currentDate}</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb', padding: 20 },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginVertical: 20 },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 20, elevation: 3 },
  counter: { fontSize: 72, fontWeight: 'bold', textAlign: 'center', color: '#2563EB' },
  label: { textAlign: 'center', fontSize: 18, color: '#555' },
  date: { textAlign: 'center', color: '#999', marginTop: 4 },
});

export default StepCounter;
