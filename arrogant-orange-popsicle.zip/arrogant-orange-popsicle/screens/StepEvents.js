import { EventEmitter } from 'events';

export const stepEmitter = new EventEmitter();
