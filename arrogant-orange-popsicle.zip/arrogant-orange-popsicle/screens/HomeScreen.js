import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ProgressCircle } from 'react-native-svg-charts';
import { stepEmitter } from './StepEvents';
import HomeScreenStyles from '../styles/HomeScreenStyles';

export default function HomeScreen({ navigation }) {
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [nextAlarm, setNextAlarm] = useState('No alarm set');
  const [stepsToday, setStepsToday] = useState(0);
  const [streak, setStreak] = useState(0);

  const stepGoal = 10000;
  const stepProgress = Math.min(stepsToday / stepGoal, 1);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const userData = await AsyncStorage.getItem('user');
        setLoggedInUser(userData ? JSON.parse(userData) : null);

        const alarmData = await AsyncStorage.getItem('sleepAlarm');
        setNextAlarm(alarmData ? JSON.parse(alarmData).time || 'No alarm set' : 'No alarm set');

        const savedRecords = await AsyncStorage.getItem('@step_records');
        const records = savedRecords ? JSON.parse(savedRecords) : {};
        const today = new Date().toISOString().split('T')[0];
        const todaySteps = records[today] || 0;
        setStepsToday(todaySteps);

        const savedStreak = await AsyncStorage.getItem('@step_streak');
        setStreak(savedStreak ? JSON.parse(savedStreak) : 0);
      } catch (e) { console.log('Error loading home data:', e); }
    };

    fetchData();

    // Live update listener
    const listener = async (count) => {
      setStepsToday(count);

      // Update streak in real time
      const savedRecords = await AsyncStorage.getItem('@step_records');
      const records = savedRecords ? JSON.parse(savedRecords) : {};
      const today = new Date().toISOString().split('T')[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

      let currentStreak = streak;
      if (count >= stepGoal) {
        const yesterdaySteps = records[yesterday] || 0;
        currentStreak = yesterdaySteps >= stepGoal ? streak + 1 : 1;
      }
      setStreak(currentStreak);
      await AsyncStorage.setItem('@step_streak', JSON.stringify(currentStreak));
    };

    stepEmitter.on('update', listener);
    return () => stepEmitter.off('update', listener);
  }, []);

  const handleProfilePress = () => navigation.navigate(loggedInUser ? 'Profile' : 'Login');

  return (
    <SafeAreaView style={HomeScreenStyles.safeArea}>
      <View style={HomeScreenStyles.header}>
        <Text style={HomeScreenStyles.appName}>Furica</Text>
        <TouchableOpacity onPress={handleProfilePress}>
          <Text style={HomeScreenStyles.profileLink}>{loggedInUser ? 'Profile' : 'Login / Register'}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={HomeScreenStyles.scrollContent}>
        <View style={HomeScreenStyles.whiteSection}>
          <View style={HomeScreenStyles.box}>
            <Text style={HomeScreenStyles.sectionTitle}>Today’s Summary</Text>
            <Text style={HomeScreenStyles.text}>
              Steps: {stepsToday.toLocaleString()} / {stepGoal.toLocaleString()}
            </Text>
          </View>

          <View style={HomeScreenStyles.box}>
            <Text style={HomeScreenStyles.sectionTitle}>Daily Goal Progress</Text>
            <View style={HomeScreenStyles.progressContainer}>
              <ProgressCircle
                style={HomeScreenStyles.progressCircle}
                progress={stepProgress}
                progressColor={'#4CAF50'}
                backgroundColor={'#E0E0E0'}
                strokeWidth={6}
              />
              <Text style={HomeScreenStyles.progressLabel}>{(stepProgress * 100).toFixed(0)}%</Text>
            </View>
          </View>

          <View style={HomeScreenStyles.box}>
            <Text style={HomeScreenStyles.sectionTitle}>Your Streak 🔥</Text>
            <Text style={HomeScreenStyles.text}>
              {streak > 0 ? `${streak}-day streak! Keep it going!` : 'No current streak. Hit 10,000 steps to start one!'}
            </Text>
          </View>

          <View style={HomeScreenStyles.box}>
            <Text style={HomeScreenStyles.sectionTitle}>Next Alarm</Text>
            <Text style={HomeScreenStyles.text}>{nextAlarm}</Text>
          </View>

          <View style={HomeScreenStyles.box}>
            <Text style={HomeScreenStyles.sectionTitle}>Quick Shortcuts</Text>
            <TouchableOpacity onPress={() => navigation.navigate('SleepAlarm')}>
              <Text style={HomeScreenStyles.link}>Set/Edit Sleep Alarm</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('StepCounter')}>
              <Text style={HomeScreenStyles.link}>View Step Counter</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
